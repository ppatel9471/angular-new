export const environment = {
  production: true,
  graphqlHost: 'https://nestjs-example-app.herokuapp.com/'
};
